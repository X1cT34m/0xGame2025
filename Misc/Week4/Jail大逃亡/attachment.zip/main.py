import os
import socket
import subprocess
import sys
import random
import hashlib
import string


"""first_challenge"""
def jail():
    player_input=input("Please input your code here: ")
    try:
        result=eval(player_input,{"__builtins__":None},{})
        print("Code have been executed")
        if result is not None:
            print(f"Return value: {result}")

    except Exception as e:
        print(f"Execution error: {type(e).__name__}: {e}")

def handle():
    os.setuid(65534)
    print("ヾ(≧▽≦*)o大家玩的开心ヾ(≧▽≦*)o\n")
    print("""
  _      __               _   _  _   _  
 / \    /__  _. ._ _   _   ) / \  ) |_  
 \_/ >< \_| (_| | | | (/_ /_ \_/ /_  _) 
                                        
""")

    try:
        count=0
        while True:
            challenge_type=random.randint(0,1)
            if challenge_type == 0:

                random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
                user_input = input(f"Please enter the reverse of '{random_str}' to continue: ").strip().upper()
                correct_answer = random_str[::-1]
            else:
                num1 = random.randint(100, 999)
                num2 = random.randint(10, 99)

                if random.choice([True, False]):
                    op = '+'
                    correct_answer = str(num1 + num2)
                    user_input = input(f"What is {num1} + {num2}? ").strip()
                else:
                    op = '-'
                    correct_answer = str(num1 - num2)
                    user_input = input(f"What is {num1} - {num2}? ").strip()

            if user_input != correct_answer:
                count += 1
                print("Error! Please try again.╰（‵□′）╯")
                if count > 3:
                    print("Too many tries, blocked")
                    break
                continue

            count = 0
            try:
                jail()
            except Exception as e:
                print(f"Error: {e}")
    except Exception as e:
        print(f"\n========== Unhandled Error! ==========\n")

def daemon_main():
    """主守护进程"""
    print("[Info] Server starting")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    pwd = os.path.dirname(__file__)

    script = open(__file__, "rb").read()
    self_fd = os.memfd_create("main")
    os.write(self_fd, script)
    os.lseek(self_fd, 0, os.SEEK_SET)
    os.chmod(self_fd, 0o400)

    try:
        sock.bind(("0.0.0.0", 5555))
        sock.listen(1)
        while True:
            try:
                conn, addr = sock.accept()
                print(f"[Info] Connected with {addr}")
                fd = conn.fileno()
                subprocess.Popen(
                    [
                        "python3",
                        "/proc/self/fd/{}".format(self_fd),
                        "fork",
                    ],
                    stdin=fd,
                    stdout=fd,
                    stderr=fd,
                    pass_fds=[self_fd], 
                    cwd=pwd,
                    env=os.environ,
                )
                conn.close()
            except Exception as e:
                print(f"[Error] {e}")
    except KeyboardInterrupt:
        print("[Info] Server stopped")
    finally:
        sock.close()
        print("[Info] Server closed")

def flag_hint():
    print("there are some important information for you")
    key='49a635cd124174a4b3e0d4c02b6224ddfaabc5e2640600cc195e29f21075dd93'
    IV='MEOHeAiC+BlLhH3FKhl0MQ=='
    Ciphertext='j+W4sfLJL4wN0rX2Qi03wqDXDb37DNtYjeYoBVIeKOt4WSUb/Sx4B8/8O4ZXA4J9'
    print("that's all,have fun!!!")


    
if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] == "fork":
        handle()
    else:
        daemon_main()


